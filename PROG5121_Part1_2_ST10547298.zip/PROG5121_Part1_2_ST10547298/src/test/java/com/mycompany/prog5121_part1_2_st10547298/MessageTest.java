/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121_part1_2_st10547298;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Wanza
 */
public class MessageTest {
    
    public MessageTest() {
    }

    @Test
    public void testCheckMessageID() {
    }

    @Test
    public void testCheckRecipientCell() {
    }

    @Test
    public void testCheckMessageLength() {
    }

    @Test
    public void testCreateMessageHash() {
    }

    @Test
    public void testSentMessage_0args() {
    }

    @Test
    public void testSentMessage_int() {
    }

    @Test
    public void testPrintMessages() {
    }

    @Test
    public void testReturnTotalMessages() {
    }

    @Test
    public void testStoreMessage() {
    }

    @Test
    public void testGetMessageID() {
    }

    @Test
    public void testGetMessageHash() {
    }

    @Test
    public void testGetRecipient() {
    }

    @Test
    public void testGetMessageText() {
    }

    @Test
    public void testGetMessageNumber() {
    }
    
}
